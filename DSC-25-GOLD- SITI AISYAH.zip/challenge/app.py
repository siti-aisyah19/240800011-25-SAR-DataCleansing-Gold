import re
import pandas as pd
import sqlite3
import json
from flask import Flask, jsonify, request
from flasgger import Swagger, LazyJSONEncoder, swag_from

app = Flask(__name__)

abuse = pd.read_csv("abusive.csv", encoding='utf-8', encoding_errors='ignore')
alay = pd.read_csv("new_kamusalay.csv", encoding='utf-8', encoding_errors='ignore', header= None)
alay = alay.rename(columns={0: 'non-baku', 1: 'baku'})

def get_db_connection():
    conn = sqlite3.connect('data.db')
    conn.execute('CREATE TABLE IF NOT EXISTS processed_text (id INTEGER PRIMARY KEY AUTOINCREMENT, original_text TEXT, clean_text TEXT)')
    conn.row_factory = sqlite3.Row
    return conn

def save_to_db(original_text, clean_text):
    conn = get_db_connection()
    conn.execute('INSERT INTO processed_text (original_text, clean_text) VALUES (?, ?)', (original_text, clean_text))
    conn.commit()
    conn.close()

app.json_encoder = LazyJSONEncoder
swagger_template = {
    'info': {
        'title': 'API Documentation for Data Processing and Modeling',
        'version': '1.0.0',
        'description': 'Dokumentasi API untuk Data Processing dan Modeling',
    },
    'host': '127.0.0.1:5000' 
}

swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": 'docs',
            "route": '/docs.json',
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/docs/"
}

swagger = Swagger(app, template=swagger_template, config=swagger_config)

def lower(text):
    return text.lower()
    
def remove_unnecessary_char(text):
    text = re.sub('\n',' ',text) 
    text = re.sub('\s+',' ',text)
    text = re.sub('\t+',' ',text)
    text = re.sub('rt',' ',text)
    text = re.sub('user',' ',text)
    text = re.sub('((www\.[^\s]+)|(https?://[^\s]+)|(http?://[^\s]+))',' ',text)
    text = re.sub('  +', ' ', text)
    return text
    
def remove_nonaplhanumeric(text):
    text = re.sub(r'\\x[0-9a-fA-F]{2}', '', text)
    text = re.sub(r'\bx[0-9a-fA-F]{1,2}\b', '', text)
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    text = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

alay_dict = dict(zip(alay['non-baku'], alay['baku']))
def fix_alay(text):
    return ' '.join([alay_dict[word] if word in alay_dict else word for word in text.split(' ')])

abuse_dict = dict(zip(abuse['ABUSIVE'], [''] * len(abuse)))
def fix_abusive(text):
    return ' '.join([abuse_dict[word] if word in abuse_dict else word for word in text.split(' ')])

def preprocess(text):
    text = lower(text)
    text = remove_unnecessary_char(text)
    text = remove_nonaplhanumeric(text)
    text = fix_alay(text)
    text = fix_abusive(text)
    return text

def process(text):
    text = lower(text)
    text = remove_unnecessary_char(text)    
    text = remove_nonaplhanumeric(text)
    text = fix_alay(text)
    text = fix_abusive(text)
    return text

@swag_from("docs/hello_world.yml", methods=['GET'])
@app.route('/', methods=['GET'])
def hello_world():
    json_response = {
        'status_code': 200,
        'description': "Menyapa Hello World",
        'data': "Hello World",
    }
    response_data = jsonify(json_response)
    return response_data

@swag_from("docs/text_processing.yml", methods=['POST'])
@app.route('/text_processing', methods=['POST'])
def text_processing():
    text = request.form.get('text')
    processed_text = preprocess(text)
    save_to_db(text, processed_text)

    json_response = { 
        'status_code':200, 
        'description':'teks bersih masuk ke database', 
        'data': processed_text,
        }

    response_data = jsonify(json_response)
    return response_data

@swag_from("docs/csv_file.yml", methods=['POST'])
@app.route('/text-processing-file', methods=['POST'])
def text_processing_file():
    # Uploaded file
    file = request.files.get('file')

    # Import CSV file into Pandas
    df = pd.read_csv(file,encoding='utf-8', encoding_errors='ignore')

    cleaned_text = []
    for text in df["Tweet"]:
        cleaned_text.append(process(text))

    json_response = {
        'status_code': 200,
        'description': "Teks yang sudah diproses",
        'data': cleaned_text,
    }

    response_data = jsonify(json_response)
    return response_data


if __name__ == "__main__":
    app.run(debug=True)